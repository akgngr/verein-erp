# DERNEK YÖNETİM SİSTEMİ — DEĞİŞİKLİK PAKETİ (27 Ekim 2026)

Bu paket, Faz 2 (Toplantılar) commit'inden sonraki TÜM değişiklikleri içerir:
Faz 3 (Üyeler) + Verein pivotu + Faz 4 (Muhasebe) + Faz 5 (Bağışlar) + kurtarma düzeltmeleri.
Kaynak commit: eeb8d02..HEAD (github.com/akgngr/verein-erp main dalı ile aynı içerik).

## NASIL UYGULANIR

1. Zip'i proje kökünde (package.json'ın olduğu klasör) çıkarın — dosyalar üzerine yazar.
2. AŞAĞIDAKİ klasörü yerelde ELLE SİLİN (kopya migration — DB kilitler):
   prisma/schema/migrations/20261027064205_add_meetings/
3. .env.local sizde yoksa .env.example'dan kopyalayıp değerleri doldurun
   (AUTH_SECRET: `openssl rand -base64 32`; ADMIN_*; DATABASE_URL).
4. Yerelde:
   pnpm install
   pnpm exec prisma migrate deploy
   pnpm exec tsx prisma/seed.ts
   pnpm dev

## SİLİNEN DOSYA (yerelde elle silinmeli)

- prisma/schema/migrations/20261027064205_add_meetings/migration.sql
  (20261026085101_add_meetings'in birebir kopyasıydı; taze DB'de
   "type MeetingType already exists" hatasıyla migrate deploy'u kilitliyordu)

## PAKET İÇERİĞİ ÖZETİ

- src/modules/members/: üye kayıt, durum yönetimi, kimlik maskeleme, notlar,
  ödeme + makbuz PDF (MAK-YYYY-NNNN) + void, Excel dışa aktarma
- src/modules/accounting/: muhasebe (hesaplar, kategoriler, projeler, kayıtlar,
  yıllar/bütçe, yıl kapanışı, üye-aidat senkronu, raporlar + PDF/Excel)
- src/modules/donations/: bağışçılar, bağışlar, makbuz (Zuwendungsbestätigung)
- src/modules/organization/: dernek bilgileri + logo yükleme
- src/shared/pdf/: ortak font/i18n/format/letterhead (de/tr)
- src/i18n/ + messages/: de/tr çeviri dosyaları
- prisma/schema/: members, accounting, donations, organization + migration'lar
- docs/specs/: faz 2/3/4/5 iş emri dokümanları
- scripts/: i18n yardımcıları + test scriptleri
